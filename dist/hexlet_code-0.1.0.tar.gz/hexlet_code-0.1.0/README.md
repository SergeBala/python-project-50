### Hexlet tests and linter status:
[![Actions Status](https://github.com/SergeBala/python-project-50/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/SergeBala/python-project-50/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/26882533786cd33e474b/maintainability)](https://codeclimate.com/github/SergeBala/python-project-50/maintainability)

[![Test Coverage](https://api.codeclimate.com/v1/badges/26882533786cd33e474b/test_coverage)](https://codeclimate.com/github/SergeBala/python-project-50/test_coverage)

[![asciicast](https://asciinema.org/a/XVXB3ba1YHeYmIXKtncBleMdK.svg)](https://asciinema.org/a/XVXB3ba1YHeYmIXKtncBleMdK)